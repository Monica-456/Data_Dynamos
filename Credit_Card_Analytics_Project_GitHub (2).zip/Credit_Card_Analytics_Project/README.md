# FinTrust Bank: Credit Card Spending, Repayment and Churn Analysis

Hackathon project **DA-02 (Team Data Dynamos)**, Codegnan.
Tools: **Python (pandas), SQL (MySQL), Excel and Power BI**.

> **About the data:** the 5,000-customer dataset in this repository is synthetic practice data, built to match the fields in the problem statement. It is not real customer data.

## The business problem
FinTrust Bank has many credit card customers across South India. Card spending is growing, but many customers have stopped using their cards or closed them, and rewards and cashback keep costing more. The bank wants to know **which customers are leaving, why, and where it is losing money**.

## Live dashboard
- Open `powerbi/FinTrust_Dashboard.html` in a browser (works offline except for the chart library).
- Or publish it free with GitHub Pages: **Settings > Pages > Branch `main` > Folder `/docs` > Save**. Your link will be `https://<your-username>.github.io/<repo-name>/`.

The dashboard has 4 filters (Month, Card type, City, Age group), 7 KPIs and 7 charts.

## Repository structure
```
Credit_Card_Analytics_Project/
├── data/
│   ├── raw/              original CSV files (do not edit)
│   ├── cleaned/          cleaned CSV files from the Python scripts
│   └── powerbi/          FinTrust_PowerBI_Ready.csv (one flat table for Power BI)
├── scripts/              01 to 05 clean each dataset, 06 builds the Power BI table, 07 builds the dashboard
├── SQl/                  MySQL tables, import template, validation, analysis and Power BI views
├── powerbi/              dashboard HTML, DAX measures, colour theme, build guide
├── docs/                 index.html (same dashboard, for GitHub Pages)
├── run_all.py            runs every script in order
├── requirements.txt
└── README.md
```

## How to run
```bash
python -m pip install -r requirements.txt
python run_all.py
```
This cleans the five datasets, builds the Power BI table and rebuilds the dashboard. You can also run one script, for example `python scripts/05_clean_transactions.py`. All scripts use paths relative to their own folder.

## Workflow
1. **Clean** the data in Python (`scripts/01` to `05`). Missing merchant categories become `Unknown`, duplicates are removed, income bands are filled with the most common value as a baseline.
2. **Analyse in SQL** (`SQl/SQL_Queries`). Run `01` first to create tables, then import the CSV files, validate row counts, and run the analysis queries.
3. **Build the Power BI table** (`scripts/06`): one row per customer per month, so no relationships are needed.
4. **Build the dashboard** in Power BI by following `powerbi/POWERBI_BUILD_GUIDE.md`. The DAX measures are in `powerbi/FinTrust_PowerBI_Simple_DAX.txt`.

## KPIs
| KPI | Definition | Value (5,000 customers) |
|---|---|---|
| Total Spend | Sum of transaction amounts | about 273.8 Cr |
| Active Cards | Customers with at least one transaction | 4,989 |
| Credit Utilisation % | Spend divided by credit limit of cards used that month | 59.1% |
| Late Payment Rate % | Statements with days late above 0 | 17.6% |
| Churn Rate % | Inactive plus Closed customers | 18.5% |
| Reward Redemption Rate | Points redeemed divided by points earned | 43.0% |

## Key findings
Each finding says what is happening, why it matters, and what the bank should do.

| What is happening | Why it matters | What the bank should do |
|---|---|---|
| Churn is 18.5% (528 inactive, 395 closed). It falls as card tier rises: Basic 21.7%, Silver 18.8%, Gold 16.1%, Platinum 13.4% | Entry-level cards lose the most customers | Give Basic card holders an upgrade or a first-year fee waiver |
| Late payments are 30.4% for Low income, 18.3% Middle, 10.3% Upper-Middle and 6.7% High. Basic cards are late 23.6% of the time, Platinum 10.0% | Risk is concentrated in low-income and Basic customers | Send payment reminders and offer auto-pay to this group |
| Customers who redeem under 20% of their points churn at 28.8%. Those who redeem over 60% churn at 10.9% and spend more on average | Rewards that are not used do not keep customers | Remind low redeemers about points and make redemption easier. This is an association, so test it before relying on it |
| Top closure reasons: better competitor offer (28.4%) and low rewards (24.3%) | Both are about value, not service | Review the rewards rate against competitors |
| Groceries, Shopping, Dining, Fuel and Utilities are the top 5 categories by spend | Everyday spending drives the revenue | Focus cashback offers on these categories |

## Three customer groups to target with retention offers
1. **Low redeemers** (under 20% redemption, 28.8% churn): points reminders and easy-redeem offers.
2. **Basic card holders with Low income** (highest late payment and churn): fee waiver, upgrade offer, payment reminders.
3. **Customers aged 18 to 25** (23.4% churn, the highest age group): starter rewards and category cashback.

These are starting points from this dataset. Check them again on the organizers' data.

## Data quality notes
- The original CSVs are kept unchanged in `data/raw/`.
- Negative transaction amounts are kept because they can be refunds.
- Missing income bands are filled with the most common value, which does not recover the real band.
- Credit utilisation here uses spending, not the outstanding balance, so treat it as an approximation.

## Deliverables checklist
- [x] Cleaning scripts and cleaned datasets
- [x] SQL files
- [x] Power BI table, DAX measures, theme and build guide
- [x] Interactive dashboard preview
- [ ] Python EDA notebook (`.ipynb`)
- [ ] Excel pivot-table workbook
- [ ] Power BI file (`.pbix`), built from the guide
- [ ] Short report and presentation
