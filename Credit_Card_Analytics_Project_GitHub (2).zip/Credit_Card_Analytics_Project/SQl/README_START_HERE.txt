FINTRUST BANK - COMPLETE SQL PROJECT FOLDER

SQL_Queries: Run 01 first to create tables. 02 is a CSV import template; update file paths. 03 validates row counts; 04 and 06 contain business analysis; 05 contains Power BI views.
Cleaned_Datasets: Five actual cleaned CSV datasets provided for this project.

IMPORTANT: These are CSV datasets, not an SQL INSERT dump. To use in MySQL, create tables first, import the CSV files, verify row counts, then run analysis. Do not rerun imports over partially imported data without checking duplicates.

Dataset row counts (excluding header):
cleaned_account_status.csv: 5,000
cleaned_customers.csv: 5,000
cleaned_repayments.csv: 36,684
cleaned_rewards.csv: 36,684
cleaned_transactions.csv: 63,954

Power BI: Connect to MySQL localhost:3306, database fintrust_bank, and select the *_clean tables.
