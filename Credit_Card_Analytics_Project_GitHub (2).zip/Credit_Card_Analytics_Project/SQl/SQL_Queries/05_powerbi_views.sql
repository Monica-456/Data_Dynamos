USE fintrust_bank;
-- Power BI-friendly summary views; no inflated totals from joining fact tables together.
CREATE OR REPLACE VIEW vw_customer_profile AS
SELECT c.customer_id,c.age_group,c.city,c.income_band,c.card_type,c.card_open_date,c.credit_limit,
 a.account_status,a.closure_date,a.closure_reason
FROM customers_clean c LEFT JOIN account_status_clean a ON a.customer_id=c.customer_id;
CREATE OR REPLACE VIEW vw_monthly_spending AS
SELECT t.customer_id,CAST(DATE_FORMAT(t.txn_date,'%Y-%m-01') AS DATE) AS spend_month,
 COUNT(*) AS txn_count,SUM(t.amount) AS total_spend
FROM transactions_clean t WHERE t.txn_date IS NOT NULL
GROUP BY t.customer_id,CAST(DATE_FORMAT(t.txn_date,'%Y-%m-01') AS DATE);
CREATE OR REPLACE VIEW vw_monthly_repayments AS
SELECT customer_id,statement_month,COUNT(*) AS repayment_count,
 SUM(bill_amount) AS total_billed,SUM(amount_paid) AS total_paid,
 SUM(CASE WHEN COALESCE(days_late,0)>0 THEN 1 ELSE 0 END) AS late_repayment_count
FROM repayments_clean GROUP BY customer_id,statement_month;
CREATE OR REPLACE VIEW vw_monthly_rewards AS
SELECT customer_id,statement_month,SUM(reward_points_earned) AS points_earned,
 SUM(points_redeemed) AS points_redeemed,SUM(cashback_amount) AS cashback_amount
FROM rewards_clean GROUP BY customer_id,statement_month;
SELECT * FROM vw_customer_profile LIMIT 10;
