-- FinTrust Bank | MySQL 8.0 | Creates separate clean tables; does not delete originals.
CREATE DATABASE IF NOT EXISTS fintrust_bank;
USE fintrust_bank;
CREATE TABLE IF NOT EXISTS customers_clean (
 customer_id VARCHAR(20) PRIMARY KEY, age_group VARCHAR(20), city VARCHAR(50),
 income_band VARCHAR(30), card_type VARCHAR(30), card_open_date DATE,
 credit_limit DECIMAL(12,2)
);
CREATE TABLE IF NOT EXISTS transactions_clean (
 txn_id VARCHAR(20) PRIMARY KEY, customer_id VARCHAR(20), txn_date DATE,
 amount DECIMAL(12,2), merchant_category VARCHAR(50), channel VARCHAR(20),
 txn_city VARCHAR(50), transaction_month VARCHAR(7), amount_category VARCHAR(20),
 INDEX idx_txn_customer(customer_id), INDEX idx_txn_date(txn_date)
);
CREATE TABLE IF NOT EXISTS repayments_clean (
 repayment_id INT AUTO_INCREMENT PRIMARY KEY, customer_id VARCHAR(20),
 statement_month DATE, bill_amount DECIMAL(12,2), amount_paid DECIMAL(12,2),
 payment_date DATE, days_late DECIMAL(10,2), payment_status VARCHAR(30),
 late_payment_status VARCHAR(30), INDEX idx_repay_customer(customer_id)
);
CREATE TABLE IF NOT EXISTS rewards_clean (
 reward_id INT AUTO_INCREMENT PRIMARY KEY, customer_id VARCHAR(20),
 statement_month DATE, reward_points_earned DECIMAL(12,2),
 points_redeemed DECIMAL(12,2), cashback_amount DECIMAL(12,2),
 remaining_points DECIMAL(12,2), redemption_status VARCHAR(30),
 INDEX idx_reward_customer(customer_id)
);
CREATE TABLE IF NOT EXISTS account_status_clean (
 customer_id VARCHAR(20) PRIMARY KEY, account_status VARCHAR(20),
 closure_date DATE, closure_reason VARCHAR(100)
);
