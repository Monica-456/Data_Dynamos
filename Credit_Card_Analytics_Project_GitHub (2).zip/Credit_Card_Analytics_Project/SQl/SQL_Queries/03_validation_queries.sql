USE fintrust_bank;
SELECT 'customers' AS dataset, COUNT(*) AS rows_loaded FROM customers_clean
UNION ALL SELECT 'transactions',COUNT(*) FROM transactions_clean
UNION ALL SELECT 'repayments',COUNT(*) FROM repayments_clean
UNION ALL SELECT 'rewards',COUNT(*) FROM rewards_clean
UNION ALL SELECT 'account_status',COUNT(*) FROM account_status_clean;
SELECT * FROM customers_clean LIMIT 10;
SELECT * FROM transactions_clean LIMIT 10;
SELECT * FROM repayments_clean LIMIT 10;
SELECT * FROM rewards_clean LIMIT 10;
SELECT * FROM account_status_clean LIMIT 10;
-- Missing customer references (possible import/data integrity issue)
SELECT COUNT(*) AS orphan_transactions FROM transactions_clean t LEFT JOIN customers_clean c ON t.customer_id=c.customer_id WHERE c.customer_id IS NULL;
SELECT COUNT(*) AS orphan_repayments FROM repayments_clean r LEFT JOIN customers_clean c ON r.customer_id=c.customer_id WHERE c.customer_id IS NULL;
SELECT COUNT(*) AS orphan_rewards FROM rewards_clean r LEFT JOIN customers_clean c ON r.customer_id=c.customer_id WHERE c.customer_id IS NULL;
