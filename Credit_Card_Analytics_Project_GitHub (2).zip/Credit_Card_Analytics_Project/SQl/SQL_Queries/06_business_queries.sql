-- FINTRUST BANK | BUSINESS QUESTIONS & SQL ANSWERS
-- MySQL 8.0 | Execute after importing all five *_clean tables.
-- NOTE: Values are calculated from your actual data when you execute these queries.
USE fintrust_bank;

-- Q01: How many customers, active cards, and closed accounts are there?
SELECT COUNT(*) AS total_customers,
 SUM(CASE WHEN LOWER(TRIM(COALESCE(a.account_status,'')))='active' THEN 1 ELSE 0 END) AS active_cards,
 SUM(CASE WHEN LOWER(TRIM(COALESCE(a.account_status,'')))='closed' THEN 1 ELSE 0 END) AS closed_accounts
FROM customers_clean c LEFT JOIN account_status_clean a ON c.customer_id=a.customer_id;

-- Q02: What is total spend, transaction count and average transaction value?
SELECT COUNT(*) AS transaction_count, ROUND(SUM(amount),2) AS total_spend,
 ROUND(AVG(amount),2) AS avg_transaction_value FROM transactions_clean;

-- Q03: How does monthly spend change over time?
SELECT DATE_FORMAT(txn_date,'%Y-%m') AS spend_month, COUNT(*) AS transactions,
 ROUND(SUM(amount),2) AS total_spend
FROM transactions_clean GROUP BY DATE_FORMAT(txn_date,'%Y-%m') ORDER BY spend_month;

-- Q04: Which merchant categories generate the most spending by quarter?
SELECT YEAR(txn_date) AS spend_year, QUARTER(txn_date) AS spend_quarter,
 merchant_category, COUNT(*) AS transaction_count, ROUND(SUM(amount),2) AS total_spend
FROM transactions_clean GROUP BY YEAR(txn_date), QUARTER(txn_date), merchant_category
ORDER BY spend_year, spend_quarter, total_spend DESC;

-- Q05: Which card types contribute the highest spend?
SELECT c.card_type, COUNT(DISTINCT c.customer_id) AS customers,
 COUNT(t.txn_id) AS transactions, ROUND(COALESCE(SUM(t.amount),0),2) AS total_spend,
 ROUND(COALESCE(SUM(t.amount),0)/NULLIF(COUNT(DISTINCT c.customer_id),0),2) AS spend_per_card
FROM customers_clean c LEFT JOIN transactions_clean t ON c.customer_id=t.customer_id
GROUP BY c.card_type ORDER BY total_spend DESC;

-- Q06: Which cities have the highest customer spend?
SELECT c.city, COUNT(DISTINCT c.customer_id) AS customers,
 ROUND(COALESCE(SUM(t.amount),0),2) AS total_spend
FROM customers_clean c LEFT JOIN transactions_clean t ON c.customer_id=t.customer_id
GROUP BY c.city ORDER BY total_spend DESC;

-- Q07: How does spending differ across age and income groups?
SELECT c.age_group,c.income_band,COUNT(DISTINCT c.customer_id) AS customers,
 ROUND(COALESCE(SUM(t.amount),0),2) AS total_spend
FROM customers_clean c LEFT JOIN transactions_clean t ON c.customer_id=t.customer_id
GROUP BY c.age_group,c.income_band ORDER BY total_spend DESC;

-- Q08: Which transaction channels are used most?
SELECT channel,COUNT(*) AS transactions,ROUND(SUM(amount),2) AS total_spend,
 ROUND(100*SUM(amount)/NULLIF((SELECT SUM(amount) FROM transactions_clean),0),2) AS spend_share_pct
FROM transactions_clean GROUP BY channel ORDER BY total_spend DESC;

-- Q09: Which customers have monthly spending above 80% of their credit limit?
-- IMPORTANT: Spending/credit limit is a proxy, NOT true outstanding-balance utilization.
SELECT t.customer_id, DATE_FORMAT(t.txn_date,'%Y-%m') AS spend_month,
 c.credit_limit, ROUND(SUM(t.amount),2) AS monthly_spend,
 ROUND(100*SUM(t.amount)/NULLIF(c.credit_limit,0),2) AS spend_to_limit_pct
FROM transactions_clean t JOIN customers_clean c ON c.customer_id=t.customer_id
WHERE c.credit_limit>0
GROUP BY t.customer_id, DATE_FORMAT(t.txn_date,'%Y-%m'),c.credit_limit
HAVING SUM(t.amount)>0.80*c.credit_limit ORDER BY spend_to_limit_pct DESC;

-- Q10: What is the late payment rate by income band and card type?
SELECT c.income_band,c.card_type,COUNT(*) AS repayment_records,
 SUM(CASE WHEN COALESCE(r.days_late,0)>0 THEN 1 ELSE 0 END) AS late_payments,
 ROUND(100*AVG(CASE WHEN COALESCE(r.days_late,0)>0 THEN 1 ELSE 0 END),2) AS late_payment_rate_pct
FROM repayments_clean r JOIN customers_clean c ON c.customer_id=r.customer_id
GROUP BY c.income_band,c.card_type ORDER BY late_payment_rate_pct DESC;

-- Q11: How much was billed versus paid each month?
SELECT DATE_FORMAT(statement_month,'%Y-%m') AS statement_period,
 ROUND(SUM(bill_amount),2) AS total_billed,ROUND(SUM(amount_paid),2) AS total_paid,
 ROUND(SUM(bill_amount-amount_paid),2) AS unpaid_amount,
 ROUND(100*SUM(amount_paid)/NULLIF(SUM(bill_amount),0),2) AS repayment_pct
FROM repayments_clean GROUP BY DATE_FORMAT(statement_month,'%Y-%m') ORDER BY statement_period;

-- Q12: Which customers have the highest number of late payments?
SELECT customer_id,COUNT(*) AS statement_count,
 SUM(CASE WHEN COALESCE(days_late,0)>0 THEN 1 ELSE 0 END) AS late_payment_count,
 ROUND(AVG(COALESCE(days_late,0)),1) AS avg_days_late
FROM repayments_clean GROUP BY customer_id HAVING late_payment_count>0
ORDER BY late_payment_count DESC,avg_days_late DESC LIMIT 25;

-- Q13: Which customers showed a three-month consecutive spending decline?
-- Uses only 3 consecutive observed calendar months, not missing months.
WITH monthly AS (
 SELECT customer_id,CAST(DATE_FORMAT(txn_date,'%Y-%m-01') AS DATE) AS month_start,
 SUM(amount) AS spend FROM transactions_clean GROUP BY customer_id,CAST(DATE_FORMAT(txn_date,'%Y-%m-01') AS DATE)
), trend AS (
 SELECT customer_id,month_start,spend,
 LAG(spend,1) OVER(PARTITION BY customer_id ORDER BY month_start) AS prior_spend,
 LAG(spend,2) OVER(PARTITION BY customer_id ORDER BY month_start) AS two_months_ago_spend,
 LAG(month_start,1) OVER(PARTITION BY customer_id ORDER BY month_start) AS prior_month,
 LAG(month_start,2) OVER(PARTITION BY customer_id ORDER BY month_start) AS two_months_ago
 FROM monthly)
SELECT customer_id,month_start,ROUND(two_months_ago_spend,2) AS spend_2_months_ago,
 ROUND(prior_spend,2) AS spend_last_month,ROUND(spend,2) AS spend_current_month
FROM trend WHERE month_start=DATE_ADD(prior_month,INTERVAL 1 MONTH)
 AND prior_month=DATE_ADD(two_months_ago,INTERVAL 1 MONTH)
 AND spend<prior_spend AND prior_spend<two_months_ago_spend
ORDER BY month_start DESC,customer_id;

-- Q14: What is the overall account closure (churn) percentage?
-- Snapshot closure share; not a time-cohort churn rate.
SELECT COUNT(*) AS total_accounts,
 SUM(CASE WHEN LOWER(TRIM(account_status))='closed' THEN 1 ELSE 0 END) AS closed_accounts,
 ROUND(100*AVG(CASE WHEN LOWER(TRIM(account_status))='closed' THEN 1 ELSE 0 END),2) AS closure_share_pct
FROM account_status_clean;

-- Q15: Which segments have the highest closure percentage?
SELECT c.card_type,c.income_band,COUNT(*) AS customers,
 SUM(CASE WHEN LOWER(TRIM(a.account_status))='closed' THEN 1 ELSE 0 END) AS closed_customers,
 ROUND(100*AVG(CASE WHEN LOWER(TRIM(a.account_status))='closed' THEN 1 ELSE 0 END),2) AS closure_share_pct
FROM customers_clean c JOIN account_status_clean a ON a.customer_id=c.customer_id
GROUP BY c.card_type,c.income_band ORDER BY closure_share_pct DESC,customers DESC;

-- Q16: What are the most common closure reasons?
SELECT COALESCE(NULLIF(TRIM(closure_reason),''),'Not specified') AS closure_reason,
 COUNT(*) AS closed_accounts FROM account_status_clean
WHERE LOWER(TRIM(account_status))='closed'
GROUP BY COALESCE(NULLIF(TRIM(closure_reason),''),'Not specified') ORDER BY closed_accounts DESC;

-- Q17: What is reward redemption rate and total cashback?
-- Points redeemed / points earned; not percentage of customers who redeemed.
SELECT ROUND(SUM(reward_points_earned),2) AS points_earned,
 ROUND(SUM(points_redeemed),2) AS points_redeemed,
 ROUND(100*SUM(points_redeemed)/NULLIF(SUM(reward_points_earned),0),2) AS points_redemption_rate_pct,
 ROUND(SUM(cashback_amount),2) AS cashback_total FROM rewards_clean;

-- Q18: Which card types redeem the most rewards?
SELECT c.card_type,ROUND(SUM(r.reward_points_earned),2) AS points_earned,
 ROUND(SUM(r.points_redeemed),2) AS points_redeemed,
 ROUND(100*SUM(r.points_redeemed)/NULLIF(SUM(r.reward_points_earned),0),2) AS redemption_rate_pct,
 ROUND(SUM(r.cashback_amount),2) AS cashback_total
FROM rewards_clean r JOIN customers_clean c ON r.customer_id=c.customer_id
GROUP BY c.card_type ORDER BY redemption_rate_pct DESC;

-- Q19: How many customers are active but have no transactions in the data?
SELECT COUNT(*) AS active_customers_without_transactions
FROM customers_clean c JOIN account_status_clean a ON a.customer_id=c.customer_id
LEFT JOIN (SELECT DISTINCT customer_id FROM transactions_clean) t ON t.customer_id=c.customer_id
WHERE LOWER(TRIM(a.account_status))='active' AND t.customer_id IS NULL;

-- Q20: What is the dashboard KPI summary?
SELECT
 (SELECT COUNT(*) FROM customers_clean) AS total_customers,
 (SELECT COUNT(*) FROM account_status_clean WHERE LOWER(TRIM(account_status))='active') AS active_cards,
 (SELECT ROUND(SUM(amount),2) FROM transactions_clean) AS total_spend,
 (SELECT ROUND(SUM(amount)/NULLIF((SELECT COUNT(*) FROM customers_clean),0),2) FROM transactions_clean) AS avg_spend_per_card,
 (SELECT ROUND(100*AVG(CASE WHEN COALESCE(days_late,0)>0 THEN 1 ELSE 0 END),2) FROM repayments_clean) AS late_payment_rate_pct,
 (SELECT ROUND(100*AVG(CASE WHEN LOWER(TRIM(account_status))='closed' THEN 1 ELSE 0 END),2) FROM account_status_clean) AS closure_share_pct,
 (SELECT ROUND(100*SUM(points_redeemed)/NULLIF(SUM(reward_points_earned),0),2) FROM rewards_clean) AS reward_redemption_rate_pct;
