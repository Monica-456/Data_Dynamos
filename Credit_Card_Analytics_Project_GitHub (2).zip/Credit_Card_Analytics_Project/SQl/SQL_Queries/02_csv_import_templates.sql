-- Replace ALL placeholder paths with your real Windows paths, using forward slashes.
-- IMPORTANT: These commands require MySQL LOCAL INFILE enabled on BOTH server and client.
-- Check actual CSV headers, order and date formats before executing.
-- Run each import ONLY into an empty target table to avoid duplicates.
-- The script is a TEMPLATE, not a complete data dump.
USE fintrust_bank;

LOAD DATA LOCAL INFILE 'C:/REPLACE_PATH/cleaned_customers.csv'
INTO TABLE customers_clean FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\r\n' IGNORE 1 LINES
(customer_id, age_group, city, income_band, card_type, @card_open_date, credit_limit)
SET card_open_date = NULLIF(@card_open_date,'');

LOAD DATA LOCAL INFILE 'C:/REPLACE_PATH/cleaned_transactions.csv'
INTO TABLE transactions_clean FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\r\n' IGNORE 1 LINES
(txn_id, customer_id, @txn_date, amount, merchant_category, channel, txn_city, transaction_month, amount_category)
SET txn_date = NULLIF(@txn_date,'');

LOAD DATA LOCAL INFILE 'C:/REPLACE_PATH/cleaned_repayments.csv'
INTO TABLE repayments_clean FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\r\n' IGNORE 1 LINES
(customer_id, @statement_month, bill_amount, amount_paid, @payment_date, days_late, payment_status, late_payment_status)
SET statement_month = NULLIF(@statement_month,''), payment_date = NULLIF(@payment_date,'');

LOAD DATA LOCAL INFILE 'C:/REPLACE_PATH/cleaned_rewards.csv'
INTO TABLE rewards_clean FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\r\n' IGNORE 1 LINES
(customer_id, @statement_month, reward_points_earned, points_redeemed, cashback_amount, remaining_points, redemption_status)
SET statement_month = NULLIF(@statement_month,'');

LOAD DATA LOCAL INFILE 'C:/REPLACE_PATH/cleaned_account_status.csv'
INTO TABLE account_status_clean FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\r\n' IGNORE 1 LINES
(customer_id, account_status, @closure_date, closure_reason)
SET closure_date = NULLIF(@closure_date,'');
