USE fintrust_bank;
-- 1 Total spending and transaction count
SELECT COUNT(*) AS transaction_count, ROUND(SUM(amount),2) AS total_spend, ROUND(AVG(amount),2) AS avg_transaction FROM transactions_clean;
-- 2 Monthly spending trend
SELECT DATE_FORMAT(txn_date,'%Y-%m') AS spend_month, COUNT(*) AS transactions, ROUND(SUM(amount),2) AS total_spend
FROM transactions_clean WHERE txn_date IS NOT NULL GROUP BY DATE_FORMAT(txn_date,'%Y-%m') ORDER BY spend_month;
-- 3 Quarterly merchant category spending
SELECT YEAR(txn_date) AS spend_year, QUARTER(txn_date) AS spend_quarter, merchant_category,
 COUNT(*) AS txn_count, ROUND(SUM(amount),2) AS total_spend
FROM transactions_clean WHERE txn_date IS NOT NULL
GROUP BY YEAR(txn_date), QUARTER(txn_date), merchant_category ORDER BY spend_year, spend_quarter, total_spend DESC;
-- 4 Spend by card type
SELECT c.card_type, COUNT(DISTINCT t.customer_id) AS spending_customers, ROUND(SUM(t.amount),2) AS total_spend
FROM transactions_clean t JOIN customers_clean c ON c.customer_id=t.customer_id GROUP BY c.card_type ORDER BY total_spend DESC;
-- 5 Spend by city
SELECT c.city, COUNT(DISTINCT c.customer_id) AS spending_customers, ROUND(SUM(t.amount),2) AS total_spend
FROM customers_clean c JOIN transactions_clean t ON c.customer_id=t.customer_id GROUP BY c.city ORDER BY total_spend DESC;
-- 6 Repayment late payment rate (rows with days_late > 0)
SELECT COUNT(*) AS repayment_records, SUM(CASE WHEN COALESCE(days_late,0)>0 THEN 1 ELSE 0 END) AS late_records,
 ROUND(100.0*SUM(CASE WHEN COALESCE(days_late,0)>0 THEN 1 ELSE 0 END)/NULLIF(COUNT(*),0),2) AS late_payment_rate_pct FROM repayments_clean;
-- 7 Late payment by income band and card type
SELECT c.income_band,c.card_type,COUNT(*) AS repayments,
 ROUND(100.0*SUM(CASE WHEN COALESCE(r.days_late,0)>0 THEN 1 ELSE 0 END)/NULLIF(COUNT(*),0),2) AS late_rate_pct
FROM repayments_clean r JOIN customers_clean c ON c.customer_id=r.customer_id GROUP BY c.income_band,c.card_type ORDER BY late_rate_pct DESC;
-- 8 Churn rate: assumes account_status values Active / Closed; inspect distinct values first
SELECT account_status,COUNT(*) AS customers FROM account_status_clean GROUP BY account_status;
SELECT COUNT(*) AS customers, SUM(CASE WHEN LOWER(TRIM(account_status))='closed' THEN 1 ELSE 0 END) AS closed_customers,
 ROUND(100.0*SUM(CASE WHEN LOWER(TRIM(account_status))='closed' THEN 1 ELSE 0 END)/NULLIF(COUNT(*),0),2) AS churn_rate_pct
FROM account_status_clean;
-- 9 Churn by card type
SELECT c.card_type, COUNT(*) AS customers,
 ROUND(100.0*SUM(CASE WHEN LOWER(TRIM(a.account_status))='closed' THEN 1 ELSE 0 END)/NULLIF(COUNT(*),0),2) AS churn_rate_pct
FROM customers_clean c JOIN account_status_clean a ON c.customer_id=a.customer_id GROUP BY c.card_type ORDER BY churn_rate_pct DESC;
-- 10 Closure reasons
SELECT closure_reason,COUNT(*) AS closed_customers FROM account_status_clean
WHERE LOWER(TRIM(account_status))='closed' GROUP BY closure_reason ORDER BY closed_customers DESC;
-- 11 Rewards and redemption
SELECT ROUND(SUM(reward_points_earned),2) AS points_earned, ROUND(SUM(points_redeemed),2) AS points_redeemed,
 ROUND(SUM(cashback_amount),2) AS cashback_total,
 ROUND(100.0*SUM(points_redeemed)/NULLIF(SUM(reward_points_earned),0),2) AS redemption_rate_pct FROM rewards_clean;
-- 12 Customers above 80% utilization PROXY: total spend in latest month divided by credit limit.
-- WARNING: spending is not outstanding balance; this is NOT true credit utilization.
WITH latest AS (SELECT MAX(DATE_FORMAT(txn_date,'%Y-%m')) AS ym FROM transactions_clean),
 monthly AS (SELECT t.customer_id,SUM(t.amount) AS spend FROM transactions_clean t JOIN latest l ON DATE_FORMAT(t.txn_date,'%Y-%m')=l.ym GROUP BY t.customer_id)
SELECT c.customer_id,c.card_type,c.credit_limit,ROUND(m.spend,2) AS latest_month_spend,
 ROUND(100.0*m.spend/NULLIF(c.credit_limit,0),2) AS spend_to_limit_pct
FROM monthly m JOIN customers_clean c ON c.customer_id=m.customer_id WHERE c.credit_limit>0 AND m.spend>0.8*c.credit_limit ORDER BY spend_to_limit_pct DESC;
-- 13 Customers with three consecutive monthly spending declines
WITH monthly AS (SELECT customer_id,CAST(DATE_FORMAT(txn_date,'%Y-%m-01') AS DATE) AS month_start,SUM(amount) AS spend
 FROM transactions_clean WHERE txn_date IS NOT NULL GROUP BY customer_id,CAST(DATE_FORMAT(txn_date,'%Y-%m-01') AS DATE)),
 lagged AS (SELECT customer_id,month_start,spend,
 LAG(spend,1) OVER(PARTITION BY customer_id ORDER BY month_start) AS m1,
 LAG(spend,2) OVER(PARTITION BY customer_id ORDER BY month_start) AS m2,
 LAG(spend,3) OVER(PARTITION BY customer_id ORDER BY month_start) AS m3,
 LAG(month_start,3) OVER(PARTITION BY customer_id ORDER BY month_start) AS date_m3
 FROM monthly)
SELECT customer_id,month_start,ROUND(spend,2) AS current_month_spend FROM lagged
WHERE m3>m2 AND m2>m1 AND m1>spend AND TIMESTAMPDIFF(MONTH,date_m3,month_start)=3 ORDER BY month_start DESC;
