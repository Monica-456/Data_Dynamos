# Build the Power BI dashboard (about 20 minutes)

This guide uses **one flat table**, so you need **no relationships** and the DAX stays short.

## Files you need

| File | What it is |
|---|---|
| `data/powerbi/FinTrust_PowerBI_Ready.csv` | The one table to load (one row per customer per month) |
| `powerbi/FinTrust_PowerBI_Simple_DAX.txt` | The 7 KPI measures to paste |
| `powerbi/FinTrust_Colourful_Theme.json` | The colour theme |
| `powerbi/FinTrust_Dashboard.html` | A working preview of the final design (open in a browser) |

If the CSV is missing, create it with `python scripts/06_build_powerbi_table.py`.

## Step 1: Load the data
Power BI Desktop > Home > Get data > Text/CSV > `FinTrust_PowerBI_Ready.csv` > Load.
The table is named `FinTrust` (60,000 rows).

## Step 2: Add the colour theme
View > Themes > Browse for themes > `FinTrust_Colourful_Theme.json`.

## Step 3: Add the 7 measures
Home > New measure. Paste **one** block from `FinTrust_PowerBI_Simple_DAX.txt` at a time, press Enter, and repeat.
Set the format: Total Spend = Currency; every rate and percentage = Percentage with 1 decimal.

## Step 4: Fix the month order
Select `month_name` > Column tools > Sort by column > `month_no`.

## Step 5: Build the page

| Visual | Fields |
|---|---|
| 4 Slicers (top row) | `month_name`, `card_type`, `city`, `age_group` |
| 7 Card visuals | Total Spend, Active Cards, Average Spend per Card, Credit Utilisation %, Late Payment Rate %, Churn Rate %, Reward Redemption Rate |
| Line chart | X `month_name`, Y Total Spend |
| Donut chart | Legend `account_status`, Values: count of `customer_id` |
| Column chart | X `card_type`, Y Total Spend |
| Column chart | X `income_band`, Y Late Payment Rate % |
| Column chart | X `card_type`, Y Churn Rate % |
| Bar chart | Y `closure_reason` (filter out "Not closed"), X: count of `customer_id` |

Layout: slicers on the first row, the 7 cards on the second row, then charts in a grid of 2 to 3 per row.
Colour the Late Payment Rate card amber and the Churn Rate card red so risk stands out.

## Step 6: Save
Save as `FinTrust_Dashboard.pbix` in this `powerbi/` folder.
(`.pbix` files are binary. Keep them under 100 MB for GitHub.)

## Check your numbers
With the 5,000-customer data, the cards should show these values:

| KPI | Expected |
|---|---|
| Total Spend | about 273.8 Cr |
| Active Cards | 4,989 |
| Late Payment Rate % | 17.6% |
| Churn Rate % | 18.5% |
| Reward Redemption Rate | 43.0% |
| Credit Utilisation % | 59.1% |

If a value is different, check the data type of the column the measure uses and that no slicer is selected.

## Definitions
- **Active card**: a card with at least one transaction in the selected period.
- **Credit utilisation**: spend divided by the credit limit of cards that were used in that month.
- **Late payment**: a statement with `days_late` above 0.
- **Churn**: a customer whose account status is Inactive or Closed.
- **Reward redemption rate**: points redeemed divided by points earned.
