"""
Step 07 - Build the interactive colourful dashboard (single HTML file).

It mirrors the Power BI design: 4 filters, 7 KPIs and 7 charts.
Input : data/powerbi/FinTrust_PowerBI_Ready.csv + data/cleaned/*.csv
Output: powerbi/FinTrust_Dashboard.html  and  docs/index.html (GitHub Pages)
Run 06_build_powerbi_table.py first.
"""
from pathlib import Path
import json
import pandas as pd

P = Path(__file__).resolve().parents[1]
f = pd.read_csv(P / "data/powerbi/FinTrust_PowerBI_Ready.csv")
cust = pd.read_csv(P / "data/cleaned/cleaned_customers.csv")
st = pd.read_csv(P / "data/cleaned/cleaned_account_status.csv")
txn = pd.read_csv(P / "data/cleaned/cleaned_transactions.csv", parse_dates=["txn_date"])
txn = txn.merge(cust[["customer_id", "card_type", "city", "age_group"]], on="customer_id")
txn["m"] = txn["txn_date"].dt.month - 1

months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
cards = ["Basic", "Silver", "Gold", "Platinum"]
cities = sorted(f["city"].unique())
ages = sorted(f["age_group"].unique())
incs = ["Low", "Middle", "Upper-Middle", "High", "Unknown"]
cats = sorted(txn["merchant_category"].fillna("Unknown").unique())
reasons = sorted(st["closure_reason"].dropna().unique())

f["m"] = f["month_no"] - 1
g = (f.groupby(["m", "card_type", "city", "age_group", "income_band"])
       .agg(spend=("spend", "sum"), txn=("txn_count", "sum"), act=("is_active_month", "sum"),
            alim=("credit_limit_active", "sum"), stm=("statements", "sum"),
            late=("late_statements", "sum"), pe=("points_earned", "sum"),
            pr=("points_redeemed", "sum"), cb=("cashback_amount", "sum")).reset_index())
F = [[int(r.m), cards.index(r.card_type), cities.index(r.city), ages.index(r.age_group),
      incs.index(r.income_band), round(r.spend), int(r.txn), int(r.act), round(r.alim),
      int(r.stm), int(r.late), int(r.pe), int(r.pr), round(r.cb)] for r in g.itertuples()]

cs = cust.merge(st, on="customer_id")
cs["ever"] = cs["customer_id"].isin(set(txn["customer_id"])).astype(int)
cg = (cs.groupby(["card_type", "city", "age_group", "income_band"])
        .agg(n=("customer_id", "size"),
             ina=("account_status", lambda s: (s == "Inactive").sum()),
             clo=("account_status", lambda s: (s == "Closed").sum()),
             ev=("ever", "sum")).reset_index())
C = [[cards.index(r.card_type), cities.index(r.city), ages.index(r.age_group),
      incs.index(r.income_band), int(r.n), int(r.ina), int(r.clo), int(r.ev)] for r in cg.itertuples()]

txn["merchant_category"] = txn["merchant_category"].fillna("Unknown")
kg = txn.groupby(["m", "card_type", "city", "age_group", "merchant_category"])["amount"].sum().reset_index()
K = [[int(r.m), cards.index(r.card_type), cities.index(r.city), ages.index(r.age_group),
      cats.index(r.merchant_category), round(r.amount)] for r in kg.itertuples()]

rg = (cs[cs["account_status"] == "Closed"]
      .groupby(["card_type", "city", "age_group", "closure_reason"]).size().reset_index(name="n"))
R = [[cards.index(r.card_type), cities.index(r.city), ages.index(r.age_group),
      reasons.index(r.closure_reason), int(r.n)] for r in rg.itertuples()]

data = dict(months=months, cards=cards, cities=cities, ages=ages, incs=incs,
            cats=cats, reasons=reasons, f=F, c=C, k=K, r=R)
html = (P / "powerbi/dashboard_template.html").read_text(encoding="utf-8")
assert "/*DATA*/null" in html
html = html.replace("/*DATA*/null", json.dumps(data, separators=(",", ":")))
(P / "powerbi/FinTrust_Dashboard.html").write_text(html, encoding="utf-8")
(P / "docs").mkdir(exist_ok=True)
(P / "docs/index.html").write_text(html, encoding="utf-8")
print("Saved powerbi/FinTrust_Dashboard.html and docs/index.html")
