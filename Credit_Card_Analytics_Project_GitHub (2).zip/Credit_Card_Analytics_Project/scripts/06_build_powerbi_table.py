"""
Step 06 - Build ONE flat table for Power BI (one row per customer per month).

Why: with a single table Power BI needs no relationships and the DAX stays simple.
Input : data/cleaned/cleaned_*.csv
Output: data/powerbi/FinTrust_PowerBI_Ready.csv
"""
from pathlib import Path
import pandas as pd

PROJECT_DIR = Path(__file__).resolve().parents[1]
CLEAN = PROJECT_DIR / "data" / "cleaned"
OUT_DIR = PROJECT_DIR / "data" / "powerbi"
OUT_DIR.mkdir(parents=True, exist_ok=True)

cust = pd.read_csv(CLEAN / "cleaned_customers.csv")
status = pd.read_csv(CLEAN / "cleaned_account_status.csv")
txn = pd.read_csv(CLEAN / "cleaned_transactions.csv", parse_dates=["txn_date"])
rep = pd.read_csv(CLEAN / "cleaned_repayments.csv")
rew = pd.read_csv(CLEAN / "cleaned_rewards.csv")

# monthly spend per customer
txn["month_start"] = txn["txn_date"].dt.to_period("M").dt.to_timestamp()
spend = (txn.groupby(["customer_id", "month_start"])
            .agg(spend=("amount", "sum"), txn_count=("amount", "size")).reset_index())

# monthly repayments per customer (late = days_late > 0)
rep["month_start"] = pd.to_datetime(rep["statement_month"])
rep["late_flag"] = (rep["days_late"].fillna(0) > 0).astype(int)
repm = (rep.groupby(["customer_id", "month_start"])
           .agg(statements=("late_flag", "size"), late_statements=("late_flag", "sum"),
                bill_amount=("bill_amount", "sum")).reset_index())

# monthly rewards per customer
rew["month_start"] = pd.to_datetime(rew["statement_month"])
rewm = (rew.groupby(["customer_id", "month_start"])
           .agg(points_earned=("reward_points_earned", "sum"),
                points_redeemed=("points_redeemed", "sum"),
                cashback_amount=("cashback_amount", "sum")).reset_index())

# every customer x every month
months = pd.DataFrame({"month_start": sorted(txn["month_start"].unique())})
base = cust.merge(status[["customer_id", "account_status", "closure_reason"]],
                  on="customer_id", how="left")
flat = base.merge(months, how="cross")
for part in (spend, repm, rewm):
    flat = flat.merge(part, on=["customer_id", "month_start"], how="left")

num = ["spend", "txn_count", "statements", "late_statements", "bill_amount",
       "points_earned", "points_redeemed", "cashback_amount"]
flat[num] = flat[num].fillna(0)
flat["closure_reason"] = flat["closure_reason"].fillna("Not closed")
flat["is_active_month"] = (flat["spend"] > 0).astype(int)
flat["credit_limit_active"] = flat["credit_limit"] * flat["is_active_month"]
flat["month_no"] = flat["month_start"].dt.month
flat["month_name"] = flat["month_start"].dt.strftime("%b")
flat["quarter"] = "Q" + flat["month_start"].dt.quarter.astype(str)
flat["month_start"] = flat["month_start"].dt.strftime("%Y-%m-%d")
flat["spend"] = flat["spend"].round(2)

cols = ["customer_id", "month_start", "month_no", "month_name", "quarter",
        "age_group", "city", "income_band", "card_type", "credit_limit",
        "account_status", "closure_reason",
        "spend", "txn_count", "is_active_month", "credit_limit_active",
        "statements", "late_statements", "bill_amount",
        "points_earned", "points_redeemed", "cashback_amount"]
out = OUT_DIR / "FinTrust_PowerBI_Ready.csv"
flat[cols].to_csv(out, index=False)
print(f"Saved {out.relative_to(PROJECT_DIR)}  rows={len(flat):,}  customers={flat.customer_id.nunique():,}")
