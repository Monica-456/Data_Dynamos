# Credit Card Analytics - Data Cleaning Project

## Folder structure

- `data/raw/` - original source CSV files. Keep these unchanged.
- `data/cleaned/` - cleaned CSV outputs.
- `scripts/` - one Python cleaning script per dataset.
- `notebooks/` - optional space for analysis notebooks.

## Setup

1. Extract this ZIP file.
2. Open a terminal in the extracted `Credit_Card_Analytics_Project` folder.
3. Install dependencies:

   ```bash
   python -m pip install -r requirements.txt
   ```

4. Run all cleaning scripts:

   ```bash
   python run_all.py
   ```

You can also run an individual script, for example:

```bash
python scripts/05_clean_transactions.py
```

The scripts use paths relative to their own location, so they do not depend on the terminal's current folder.

## Important data-quality notes

- The original CSVs are preserved in `data/raw/`.
- Missing transaction merchant categories are labeled `Unknown`.
- Negative transaction amounts are retained because they may represent refunds.
- Duplicate-key removal follows the assumptions documented in each script. Review duplicate reports before using the data for business decisions.
- Missing income bands in the customer script are filled with the mode as a baseline approach. This does not recover the customer's actual income band.
- The cleaned transaction output is included in `data/cleaned/`.

## Files

- `scripts/01_clean_account_status.py`
- `scripts/02_clean_customers.py`
- `scripts/03_clean_repayments.py`
- `scripts/04_clean_rewards.py`
- `scripts/05_clean_transactions.py`
