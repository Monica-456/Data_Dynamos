from pathlib import Path
import subprocess
import sys

PROJECT_DIR = Path(__file__).resolve().parent
scripts = [
    "01_clean_account_status.py",
    "02_clean_customers.py",
    "03_clean_repayments.py",
    "04_clean_rewards.py",
    "05_clean_transactions.py",
]

for script in scripts:
    script_path = PROJECT_DIR / "scripts" / script
    print(f"\n{'=' * 15} Running {script} {'=' * 15}")
    result = subprocess.run([sys.executable, str(script_path)], cwd=PROJECT_DIR)
    if result.returncode != 0:
        raise SystemExit(f"Stopped: {script} failed with exit code {result.returncode}")

print("\nAll five cleaning scripts completed successfully.")
