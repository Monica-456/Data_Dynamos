
# ==========================================
# TRANSACTIONS DATASET - COMPLETE DATA CLEANING
# ==========================================

# STEP 1: Import libraries
import pandas as pd
import numpy as np
from pathlib import Path

# Find the main project folder reliably
BASE_DIR = Path(__file__).resolve().parent.parent
RAW_DIR = BASE_DIR / 'data' / 'raw'
CLEANED_DIR = BASE_DIR / 'data' / 'cleaned'
CLEANED_DIR.mkdir(parents=True, exist_ok=True)

# STEP 2: Load dataset
df = pd.read_csv(RAW_DIR / "transactions_5000.csv")

# STEP 3: Initial inspection
print("First 5 Records:")
print(df.head())

print("\nDataset Shape:")
print(df.shape)

print("\nDataset Information:")
df.info()

# STEP 4: Check duplicate rows
print("\nDuplicate Rows:", df.duplicated().sum())

# Remove exact duplicate rows
df = df.drop_duplicates()

# STEP 5: Check duplicate transaction IDs
print("\nDuplicate Transaction IDs:",
      df["txn_id"].duplicated().sum())

# Remove duplicate transaction IDs only after
# checking which transaction record is correct.
# Here we retain the first occurrence.
df = df.drop_duplicates(
    subset=["txn_id"],
    keep="first"
)

# STEP 6: Clean column names
df.columns = df.columns.str.strip().str.lower()

# STEP 7: Clean text columns
text_columns = [
    "txn_id",
    "customer_id",
    "merchant_category",
    "channel",
    "txn_city"
]

for col in text_columns:
    df[col] = df[col].astype("string").str.strip()

# Standardize text values
df["merchant_category"] = (
    df["merchant_category"].str.title()
)

df["channel"] = df["channel"].str.title()

df["txn_city"] = df["txn_city"].str.title()

# Replace empty strings with missing values
df[text_columns] = df[text_columns].replace(
    r"^\s*$", pd.NA, regex=True
)

# STEP 8: Convert transaction date
df["txn_date"] = pd.to_datetime(
    df["txn_date"],
    errors="coerce"
)

# STEP 9: Convert transaction amount into numeric
df["amount"] = pd.to_numeric(
    df["amount"],
    errors="coerce"
)

# STEP 10: Check missing values
print("\nMissing Values:")
print(df.isnull().sum())

# STEP 11: Handle missing merchant categories
# Use Unknown instead of deleting transactions
df["merchant_category"] = (
    df["merchant_category"].fillna("Unknown")
)

# STEP 12: Check negative transaction amounts
negative_amounts = df[df["amount"] < 0]

print("\nNegative Transaction Amounts:")
print(negative_amounts)

# Negative amounts may represent refunds or reversals.
# Do not delete them without checking business rules.

# STEP 13: Check zero transaction amounts
zero_amounts = df[df["amount"] == 0]

print("\nZero Transaction Amounts:")
print(zero_amounts)

# STEP 14: Check transaction dates
future_transactions = df[
    df["txn_date"] > pd.Timestamp.today()
]

print("\nFuture Transaction Dates:")
print(future_transactions)

# STEP 15: Validate transaction channels
print("\nChannel Counts:")
print(df["channel"].value_counts(dropna=False))

# STEP 16: Validate merchant categories
print("\nMerchant Category Counts:")
print(
    df["merchant_category"].value_counts(
        dropna=False
    )
)

# STEP 17: Create transaction month column
df["transaction_month"] = (
    df["txn_date"].dt.to_period("M").astype("string")
)

# STEP 18: Create transaction amount category
df["amount_category"] = np.select(
    [
        df["amount"] < 1000,
        df["amount"].between(1000, 5000),
        df["amount"] > 5000
    ],
    [
        "Low",
        "Medium",
        "High"
    ],
    default="Unknown"
)

# STEP 19: Final validation
print("\nFinal Dataset Shape:")
print(df.shape)

print("\nFinal Missing Values:")
print(df.isnull().sum())

print("\nFinal Duplicate Rows:")
print(df.duplicated().sum())

# STEP 20: Transaction statistics
print("\nTransaction Amount Statistics:")
print(df["amount"].describe())

# STEP 21: Transactions by Merchant Category
print("\nTransactions by Merchant:")
print(df["merchant_category"].value_counts())

# STEP 22: Transactions by Channel
print("\nTransactions by Channel:")
print(df["channel"].value_counts())

# STEP 23: Export cleaned dataset
df.to_csv(CLEANED_DIR / "cleaned_transactions.csv", index=False)

print("\nTransactions Dataset Cleaned Successfully!")
