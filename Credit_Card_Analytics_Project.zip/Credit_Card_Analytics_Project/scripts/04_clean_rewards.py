
# ==========================================
# REWARDS DATASET - COMPLETE DATA CLEANING
# ==========================================

# STEP 1: Import libraries
import pandas as pd
import numpy as np
from pathlib import Path

# Find the main project folder reliably
BASE_DIR = Path(__file__).resolve().parent.parent
RAW_DIR = BASE_DIR / 'data' / 'raw'
CLEANED_DIR = BASE_DIR / 'data' / 'cleaned'
CLEANED_DIR.mkdir(parents=True, exist_ok=True)

# STEP 2: Load dataset
df = pd.read_csv(RAW_DIR / "rewards_5000.csv")

# STEP 3: Initial inspection
print("First 5 Records:")
print(df.head())

print("\nDataset Shape:")
print(df.shape)

print("\nDataset Information:")
df.info()

# STEP 4: Check duplicate rows
print("\nDuplicate Rows:", df.duplicated().sum())

# Remove exact duplicate rows
df = df.drop_duplicates()

# Check duplicate customer and statement month
print("\nDuplicate Customer-Month Records:")
print(
    df.duplicated(
        subset=["customer_id", "statement_month"]
    ).sum()
)

# Remove duplicate customer-month records
# Retain first record only if one record per month is expected
df = df.drop_duplicates(
    subset=["customer_id", "statement_month"],
    keep="first"
)

# STEP 5: Clean column names
df.columns = df.columns.str.strip().str.lower()

# STEP 6: Clean customer IDs
df["customer_id"] = (
    df["customer_id"].astype("string").str.strip()
)

# STEP 7: Clean statement month
df["statement_month"] = (
    df["statement_month"].astype("string").str.strip()
)

# Convert statement month into datetime
df["statement_month"] = pd.to_datetime(
    df["statement_month"],
    format="%Y-%m",
    errors="coerce"
)

# STEP 8: Convert numeric columns
numeric_columns = [
    "reward_points_earned",
    "points_redeemed",
    "cashback_amount"
]

for col in numeric_columns:
    df[col] = pd.to_numeric(
        df[col],
        errors="coerce"
    )

# STEP 9: Check missing values
print("\nMissing Values:")
print(df.isnull().sum())

# STEP 10: Check negative reward points
negative_earned = df[
    df["reward_points_earned"] < 0
]

print("\nNegative Reward Points:")
print(negative_earned)

# Replace invalid negative points with NaN
df.loc[
    df["reward_points_earned"] < 0,
    "reward_points_earned"
] = np.nan

# STEP 11: Check negative redeemed points
negative_redeemed = df[
    df["points_redeemed"] < 0
]

print("\nNegative Redeemed Points:")
print(negative_redeemed)

# Replace invalid negative points with NaN
df.loc[
    df["points_redeemed"] < 0,
    "points_redeemed"
] = np.nan

# STEP 12: Check negative cashback
negative_cashback = df[
    df["cashback_amount"] < 0
]

print("\nNegative Cashback:")
print(negative_cashback)

# Replace invalid negative cashback with NaN
df.loc[
    df["cashback_amount"] < 0,
    "cashback_amount"
] = np.nan

# STEP 13: Check redeemed points greater than earned points
invalid_redemption = df[
    df["points_redeemed"] >
    df["reward_points_earned"]
]

print("\nRedeemed More Than Earned:")
print(invalid_redemption)

# Do not automatically delete these records.
# Check whether opening reward balances or carry-forward
# points are included in the business rules.

# STEP 14: Create remaining points column
df["remaining_points"] = (
    df["reward_points_earned"] -
    df["points_redeemed"]
)

# Keep invalid negative remaining balances for investigation
# rather than replacing them with zero.

# STEP 15: Create redemption status
df["redemption_status"] = np.select(
    [
        df["points_redeemed"] == 0,
        df["points_redeemed"] > 0
    ],
    [
        "Not Redeemed",
        "Redeemed"
    ],
    default="Unknown"
)

# STEP 16: Check cashback statistics
print("\nCashback Statistics:")
print(df["cashback_amount"].describe())

# STEP 17: Final validation
print("\nFinal Dataset Shape:")
print(df.shape)

print("\nFinal Missing Values:")
print(df.isnull().sum())

print("\nFinal Duplicate Rows:")
print(df.duplicated().sum())

print("\nRedemption Status:")
print(df["redemption_status"].value_counts())

# STEP 18: Export cleaned dataset
df.to_csv(CLEANED_DIR / "cleaned_rewards.csv", index=False)

print("\nRewards Dataset Cleaned Successfully!")
