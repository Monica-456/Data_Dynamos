import pandas as pd
import numpy as np
from pathlib import Path

# Find the main project folder reliably
BASE_DIR = Path(__file__).resolve().parent.parent
RAW_DIR = BASE_DIR / 'data' / 'raw'
CLEANED_DIR = BASE_DIR / 'data' / 'cleaned'
CLEANED_DIR.mkdir(parents=True, exist_ok=True)

#Import libraries and load dataset
df = pd.read_csv(RAW_DIR / "account_status_5000.csv")

print(df.head())
print(df.shape)
print(df.info())

#Check missing values
print(df.isnull().sum())

#Check missing-value percentages:
missing_percentage = (df.isnull().sum() / len(df)) * 100

print(missing_percentage)

#Remove duplicate records
print("Duplicate rows:", df.duplicated().sum())

df = df.drop_duplicates()

#Check duplicate customer IDs:
print(df["customer_id"].duplicated().sum())

df = df.drop_duplicates(subset=["customer_id"], keep="first")

#Clean text columns
text_columns = ["customer_id", "account_status", "closure_reason"]

for col in text_columns:
    df[col] = df[col].str.strip()


df["account_status"] = df["account_status"].str.title()



#Convert date colum
df["closure_date"] = pd.to_datetime(
    df["closure_date"],
    errors="coerce"
)

#Handle missing values

print(df.groupby("account_status")[
    ["closure_date", "closure_reason"]
].apply(lambda x: x.isnull().sum()))


closed_missing = df[
    (df["account_status"] == "Closed") &
    (df["closure_date"].isnull() | df["closure_reason"].isnull())
]

print(closed_missing)


#Validate data
print(df["account_status"].value_counts())

valid_status = ["Active", "Inactive", "Closed"]

invalid_status = df[
    ~df["account_status"].isin(valid_status)
]

print(invalid_status)

print(df["customer_id"].isnull().sum())


#Final dataset inspection
print("Final Shape:", df.shape)

print("Missing Values:")
print(df.isnull().sum())

print("Duplicate Rows:", df.duplicated().sum())

print(df.head())

#Export cleaned dataset
df.to_csv(CLEANED_DIR / "cleaned_account_status.csv", index=False)

print("Account Status Dataset Cleaned Successfully!")




