
# ==========================================
# REPAYMENTS DATASET - COMPLETE DATA CLEANING
# ==========================================

# STEP 1: Import libraries
import pandas as pd
import numpy as np
from pathlib import Path

# Find the main project folder reliably
BASE_DIR = Path(__file__).resolve().parent.parent
RAW_DIR = BASE_DIR / 'data' / 'raw'
CLEANED_DIR = BASE_DIR / 'data' / 'cleaned'
CLEANED_DIR.mkdir(parents=True, exist_ok=True)

# STEP 2: Load dataset
df = pd.read_csv(RAW_DIR / "repayments_5000.csv")

# STEP 3: Initial inspection
print("First 5 Records:")
print(df.head())

print("\nDataset Shape:")
print(df.shape)

print("\nDataset Information:")
df.info()

# STEP 4: Check duplicate rows
print("\nDuplicate Rows:", df.duplicated().sum())

# Remove exact duplicate rows
df = df.drop_duplicates()

# Check duplicate customer and statement month combinations
print("\nDuplicate Customer-Month Records:")
print(
    df.duplicated(
        subset=["customer_id", "statement_month"]
    ).sum()
)

# Remove duplicate customer-month records only after
# checking which record is correct.
# Here we retain the first record as a cleaning rule.
df = df.drop_duplicates(
    subset=["customer_id", "statement_month"],
    keep="first"
)

# STEP 5: Clean column names
df.columns = df.columns.str.strip().str.lower()

# STEP 6: Clean customer ID
df["customer_id"] = (
    df["customer_id"].astype("string").str.strip()
)

# STEP 7: Clean statement month
df["statement_month"] = (
    df["statement_month"].astype("string").str.strip()
)

# Convert statement month into datetime
df["statement_month"] = pd.to_datetime(
    df["statement_month"],
    format="%Y-%m",
    errors="coerce"
)

# STEP 8: Convert payment date into datetime
df["payment_date"] = pd.to_datetime(
    df["payment_date"],
    errors="coerce"
)

# STEP 9: Convert amount columns into numeric
numeric_columns = [
    "bill_amount",
    "amount_paid",
    "days_late"
]

for col in numeric_columns:
    df[col] = pd.to_numeric(
        df[col],
        errors="coerce"
    )

# STEP 10: Check missing values
print("\nMissing Values:")
print(df.isnull().sum())

# STEP 11: Check negative bill amounts
negative_bills = df[df["bill_amount"] < 0]

print("\nNegative Bill Amounts:")
print(negative_bills)

# Replace invalid negative bills with NaN
df.loc[df["bill_amount"] < 0, "bill_amount"] = np.nan

# STEP 12: Check negative payment amounts
negative_payments = df[df["amount_paid"] < 0]

print("\nNegative Payments:")
print(negative_payments)

# Replace invalid negative payments with NaN
df.loc[df["amount_paid"] < 0, "amount_paid"] = np.nan

# STEP 13: Check negative days late
negative_days = df[df["days_late"] < 0]

print("\nNegative Days Late:")
print(negative_days)

# Replace invalid negative days with NaN
df.loc[df["days_late"] < 0, "days_late"] = np.nan

# STEP 14: Check overpayments
overpayments = df[
    df["amount_paid"] > df["bill_amount"]
]

print("\nOverpayment Records:")
print(overpayments)

# Do not automatically remove overpayments.
# They may represent advance payments or credits.

# STEP 15: Check date consistency
invalid_dates = df[
    df["payment_date"] < df["statement_month"]
]

print("\nPayment Before Statement Month:")
print(invalid_dates)

# These records need investigation.
# Do not delete them automatically.

# STEP 16: Create payment status column
df["payment_status"] = np.select(
    [
        df["amount_paid"] == 0,
        df["amount_paid"] < df["bill_amount"],
        df["amount_paid"] == df["bill_amount"],
        df["amount_paid"] > df["bill_amount"]
    ],
    [
        "Unpaid",
        "Partially Paid",
        "Fully Paid",
        "Overpaid"
    ],
    default="Unknown"
)

# STEP 17: Create late payment category
df["late_payment_status"] = np.where(
    df["days_late"] > 0,
    "Late",
    "On Time"
)

# Preserve missing days_late as unknown
df.loc[
    df["days_late"].isna(),
    "late_payment_status"
] = "Unknown"

# STEP 18: Final validation
print("\nFinal Dataset Shape:")
print(df.shape)

print("\nFinal Missing Values:")
print(df.isnull().sum())

print("\nFinal Duplicate Rows:")
print(df.duplicated().sum())

print("\nPayment Status Counts:")
print(df["payment_status"].value_counts())

print("\nLate Payment Counts:")
print(df["late_payment_status"].value_counts())

# STEP 19: Export cleaned dataset
df.to_csv(CLEANED_DIR / "cleaned_repayments.csv", index=False)

print("\nRepayments Dataset Cleaned Successfully!")
