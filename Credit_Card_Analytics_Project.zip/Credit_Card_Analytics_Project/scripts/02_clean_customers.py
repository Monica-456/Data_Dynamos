
# ==========================================
# CUSTOMER DATASET - COMPLETE DATA CLEANING
# ==========================================

# STEP 1: Import libraries
import pandas as pd
import numpy as np
from pathlib import Path

# Find the main project folder reliably
BASE_DIR = Path(__file__).resolve().parent.parent
RAW_DIR = BASE_DIR / 'data' / 'raw'
CLEANED_DIR = BASE_DIR / 'data' / 'cleaned'
CLEANED_DIR.mkdir(parents=True, exist_ok=True)

# STEP 2: Load dataset
df = pd.read_csv(RAW_DIR / "customers_5000.csv")

# STEP 3: Initial inspection
print("First 5 Records:")
print(df.head())

print("\nDataset Shape:")
print(df.shape)

print("\nDataset Information:")
df.info()

# STEP 4: Check duplicate records
print("\nDuplicate Rows:", df.duplicated().sum())

# Remove exact duplicate rows
df = df.drop_duplicates()

# Check duplicate customer IDs
print("\nDuplicate Customer IDs:",
      df["customer_id"].duplicated().sum())

# Remove duplicate customer IDs, retaining first record
# Only appropriate if customer_id must be unique
df = df.drop_duplicates(subset=["customer_id"], keep="first")

# STEP 5: Clean column names
df.columns = df.columns.str.strip().str.lower()

# STEP 6: Clean text columns
text_columns = [
    "customer_id",
    "age_group",
    "city",
    "income_band",
    "card_type"
]

for col in text_columns:
    df[col] = df[col].astype("string").str.strip()

# Standardize text values
df["city"] = df["city"].str.title()
df["income_band"] = df["income_band"].str.title()
df["card_type"] = df["card_type"].str.title()
df["age_group"] = df["age_group"].str.strip()

# Replace empty strings with missing values
df[text_columns] = df[text_columns].replace(
    r"^\s*$", pd.NA, regex=True
)

# STEP 7: Check missing values
print("\nMissing Values Before Cleaning:")
print(df.isnull().sum())

# STEP 8: Handle missing income_band
# Check the most frequent income category
print("\nIncome Band Counts:")
print(df["income_band"].value_counts(dropna=False))

# Fill missing income_band with mode
# This is a simple baseline approach, not a verified income value
income_mode = df["income_band"].mode()

if not income_mode.empty:
    df["income_band"] = df["income_band"].fillna(
        income_mode.iloc[0]
    )

# STEP 9: Convert date column
df["card_open_date"] = pd.to_datetime(
    df["card_open_date"],
    errors="coerce"
)

# STEP 10: Convert credit_limit into numeric
df["credit_limit"] = pd.to_numeric(
    df["credit_limit"],
    errors="coerce"
)

# STEP 11: Validate credit limit
# Credit limit should not be negative
invalid_credit = df[df["credit_limit"] < 0]

print("\nInvalid Credit Limits:")
print(invalid_credit)

# Replace negative credit limits with missing values
df.loc[df["credit_limit"] < 0, "credit_limit"] = np.nan

# STEP 12: Validate age groups
valid_age_groups = [
    "18-25",
    "26-35",
    "36-45",
    "46-55",
    "56-65",
    "65+"
]

invalid_age = df[
    ~df["age_group"].isin(valid_age_groups)
]

print("\nInvalid Age Groups:")
print(invalid_age)

# STEP 13: Validate card types
print("\nCard Type Counts:")
print(df["card_type"].value_counts(dropna=False))

# STEP 14: Check future opening dates
today = pd.Timestamp.today().normalize()

future_dates = df[df["card_open_date"] > today]

print("\nFuture Opening Dates:")
print(future_dates)

# STEP 15: Final missing value check
print("\nFinal Missing Values:")
print(df.isnull().sum())

# STEP 16: Final duplicate check
print("\nFinal Duplicate Rows:", df.duplicated().sum())

print("\nFinal Dataset Shape:")
print(df.shape)

# STEP 17: Export cleaned dataset
df.to_csv(CLEANED_DIR / "cleaned_customers.csv", index=False)

print("\nCustomer Dataset Cleaned Successfully!")
